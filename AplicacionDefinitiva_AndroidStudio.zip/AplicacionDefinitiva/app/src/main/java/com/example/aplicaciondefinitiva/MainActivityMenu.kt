package com.example.aplicaciondefinitiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast

class MainActivityMenu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)
        val encuesta= findViewById<ImageButton>(R.id.imageButtonEncuesta)
        val cajero= findViewById<ImageButton>(R.id.imageButtonCajero)
        val juego= findViewById<ImageButton>(R.id.imageButtonJuego)
        val agenda=findViewById<ImageButton>(R.id.imageButtonAgenda)
        val cerrar=findViewById<Button>(R.id.buttonCerrarSesion)
        encuesta.setOnClickListener {
            val intento= Intent(this, MainActivityEncuesta::class.java)
            startActivity(intento)

        }
        cajero.setOnClickListener {
            val intento= Intent(this, MainActivityCajero::class.java)
            startActivity(intento)

        }
        juego.setOnClickListener {
            val intento= Intent(this, MainActivityJuego::class.java)
            startActivity(intento)

        }
        cerrar.setOnClickListener {
            val intento= Intent(this, MainActivity::class.java)
            startActivity(intento)
            Toast.makeText(this,"¡Adiós!", Toast.LENGTH_LONG).show()

        }
    }
}