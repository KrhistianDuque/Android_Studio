package com.example.aplicaciondefinitiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast


class MainActivityCajero : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_cajero)
        var comprobarSaldo= findViewById<Button>(R.id.buttoncomprobarSaldo)
        var retirarSaldo= findViewById<Button>(R.id.buttonRetirarSaldo)
        var depositarSaldo= findViewById<Button>(R.id.buttonDepositarSaldo)
        var retirarCampo=findViewById<EditText>(R.id.editTextRetirarCampo)
        var depositarCampo=findViewById<EditText>(R.id.editTextDepositarCampo)
        var saldo = 10000.0
        val volver=findViewById<Button>(R.id.buttonVolverCajero)
        volver.setOnClickListener {
            val intento= Intent(this, MainActivityMenu::class.java)
            startActivity(intento)
            Toast.makeText(this,"¡Has vuelto al menú!", Toast.LENGTH_LONG).show()
        }
        comprobarSaldo.setOnClickListener {
            Toast.makeText(this, "Su saldo Actual es: ${saldo}", Toast.LENGTH_LONG).show()
        }
        retirarSaldo.setOnClickListener {
            val cantidadRetirar = retirarCampo.text.toString().toDoubleOrNull()
            if (cantidadRetirar != null && cantidadRetirar > 0) {
                if (cantidadRetirar <= saldo) {
                    saldo -= cantidadRetirar
                    Toast.makeText(this, "Retiro exitoso. Su saldo Actual es: $saldo", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Fondos insuficientes", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Cantidad no válida", Toast.LENGTH_LONG).show()
            }
        }
        depositarSaldo.setOnClickListener {
            val cantidadDepositar = depositarCampo.text.toString().toDoubleOrNull()
            if (cantidadDepositar != null && cantidadDepositar > 0) {
                saldo += cantidadDepositar
                Toast.makeText(this, "Depósito exitoso. Su saldo Actual es: $saldo", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Cantidad no válida", Toast.LENGTH_LONG).show()
            }
        }


    }

}