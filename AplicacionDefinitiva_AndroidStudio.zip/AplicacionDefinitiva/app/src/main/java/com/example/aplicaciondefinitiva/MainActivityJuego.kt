package com.example.aplicaciondefinitiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlin.random.Random

class MainActivityJuego : AppCompatActivity() {
    var numeroAdivinar = 0
    var intentos = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_juego)

        var Suposicion=findViewById<EditText>(R.id.editTextSuposicion)
        var comprobarBoton = findViewById<Button>(R.id.buttonComprobarNumero)
        var numeroAdivinar = Random.nextInt(1, 101)
        val volver=findViewById<Button>(R.id.buttonVolverJuego)
        volver.setOnClickListener {
            val intento= Intent(this, MainActivityMenu::class.java)
            startActivity(intento)
            Toast.makeText(this,"¡Has vuelto al menú!", Toast.LENGTH_LONG).show()
        }
        comprobarBoton.setOnClickListener {
            val suposicion = Suposicion.text.toString().toIntOrNull()

            if (suposicion == null) {
                Toast.makeText(this, "Por favor, Ingrese un número válido", Toast.LENGTH_LONG).show()
            }else if(suposicion<numeroAdivinar){
                Toast.makeText(this, "Más alto", Toast.LENGTH_LONG).show()
            }else if(suposicion>numeroAdivinar){
                Toast.makeText(this, "Más bajo", Toast.LENGTH_LONG).show()
            }else if(suposicion==numeroAdivinar){
                Toast.makeText(this, "¡Felicidades! Adivinaste el número en $intentos intentos, el numero era ${numeroAdivinar}.", Toast.LENGTH_LONG).show()
            }

            intentos++

        }
    }
}