package com.example.aplicaciondefinitiva

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivityAgenda : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_agenda)
        var nombre=findViewById<EditText>(R.id.editTextNombre)
        var datos=findViewById<EditText>(R.id.editTextDatos)
        var guardar=findViewById<Button>(R.id.buttonGuardar)
        var consultar=findViewById<Button>(R.id.buttonConsultar)
        var almacenarDatos= getSharedPreferences("Agenda", Context.MODE_PRIVATE)
        val volver=findViewById<Button>(R.id.buttonVolverAgenda)
        volver.setOnClickListener {
            val intento= Intent(this, MainActivityMenu::class.java)
            startActivity(intento)
            Toast.makeText(this,"¡Has vuelto al menú!", Toast.LENGTH_LONG).show()
        }
        guardar.setOnClickListener {
            val editor= almacenarDatos.edit()
            editor.putString(nombre.text.toString(), datos.text.toString())
            editor.commit()

            Toast.makeText(this, "Datos guardados", Toast.LENGTH_LONG).show()

            nombre.setText("")
            datos.setText("")
        }
        consultar.setOnClickListener {

            val datosConsultados=almacenarDatos.getString(nombre.text.toString(),"")

            if(datosConsultados != null){
                if (datosConsultados.length==0){
                    Toast.makeText(this, "La persona no existe", Toast.LENGTH_SHORT).show()
                }else{
                    datos.setText(datosConsultados)
                }

            }
        }
    }
}