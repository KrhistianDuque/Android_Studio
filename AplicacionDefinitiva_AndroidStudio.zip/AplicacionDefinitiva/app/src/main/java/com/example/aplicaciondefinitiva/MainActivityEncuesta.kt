package com.example.aplicaciondefinitiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Toast

class MainActivityEncuesta : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_encuesta)
        val femenino=findViewById<RadioButton>(R.id.radioButtonFemenino)
        val masculino=findViewById<RadioButton>(R.id.radioButtonMasculino)
        val otro=findViewById<RadioButton>(R.id.radioButtonOtro)
        val guardar=findViewById<Button>(R.id.buttonGuardar)
        var resultadoGenero=""
        val java=findViewById<CheckBox>(R.id.checkBoxJava)
        val kotlin=findViewById<CheckBox>(R.id.checkBoxKotlin)
        var resultadoMateria=""
        val volver=findViewById<Button>(R.id.buttonVolverEncuesta)

        volver.setOnClickListener {
            val intento= Intent(this, MainActivityMenu::class.java)
            startActivity(intento)
            Toast.makeText(this,"¡Has vuelto al menú!", Toast.LENGTH_LONG).show()
        }
        guardar.setOnClickListener {
            if(femenino.isChecked){
                resultadoGenero="Femenino"
            }else if(masculino.isChecked){
                resultadoGenero="Masculino"
            }else if(otro.isChecked){
                resultadoGenero="Otro"
            }else{
                resultadoGenero="No seleccionó Genero"
            }

            if(java.isChecked){
                resultadoMateria="Java"
            }else if(kotlin.isChecked){
                resultadoMateria="Kotlin"
            }else if(java.isChecked && kotlin.isChecked){
                resultadoMateria="Todos"
            }else{
                resultadoMateria="No seleccionó materia"
            }
            Toast.makeText(this, "Genero: ${resultadoGenero}, Materia: ${resultadoMateria}", Toast.LENGTH_LONG).show()
        }
    }
}