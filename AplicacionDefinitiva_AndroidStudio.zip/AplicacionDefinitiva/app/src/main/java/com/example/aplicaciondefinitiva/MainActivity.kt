package com.example.aplicaciondefinitiva

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(/* layoutResID = */ R.layout.activity_main)
        val usuario=findViewById<EditText>(R.id.editTextUsuario)
        val clave= findViewById<EditText>(R.id.editTextPasswordClave)
        val iniciar= findViewById<Button>(R.id.button)
        iniciar.setOnClickListener {
           if(usuario.text.toString().equals("Admin") && clave.text.toString().equals("1234")){
                val intento= Intent(this, MainActivityMenu::class.java)
                startActivity(intento)
               Toast.makeText(this,"¡Beinvenido ${usuario}!", Toast.LENGTH_LONG).show()
           }else{
               Toast.makeText(this,"¡Datos Incorrectos!", Toast.LENGTH_LONG).show()
           }
        }
    }
}